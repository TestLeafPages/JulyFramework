package com.leaftaps.pages;

import com.leataps.testng.base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod{
public ViewLeadPage verifyLeadCreation() {
	System.out.println("Verified");
	return this;
}
}
